# EggWars

### This plugin is under development

_EggWars minigame for PocketMine_

- Credits:
    - Muqsit - InvMenu virion
